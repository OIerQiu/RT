mod color;
mod ray;
mod hittable;
mod sphere;
mod hittable_list;
mod interval;
mod camera;
mod rtweekend;
mod vec3;
mod material;

use nalgebra::Vector3;
use std::sync::Arc;

use crate::color::write_color;
use crate::ray::Ray;
use crate::hittable::{HitRecord,Hittable};
use crate::hittable_list::HittableList;
use crate::sphere::Sphere;
use crate::interval::Interval;
use crate::camera::Camera;
use crate::material::{Material, Lambertian, Metal};

fn main() {
    let mut world = HittableList::new();
    let material_ground = Arc::new(Lambertian::new(Vector3::new(0.8,0.8,0.0)));
    let material_center = Arc::new(Lambertian::new(Vector3::new(0.1,0.2,0.5)));
    let material_left = Arc::new(Metal::new(Vector3::new(0.8,0.8,0.8),0.3));
    let material_right = Arc::new(Metal::new(Vector3::new(0.8,0.6,0.2),1.0));
    world.add(Arc::new(Sphere::new(Vector3::new(0.0,-100.5,-1.0),100.0, material_ground)));
    world.add(Arc::new(Sphere::new(Vector3::new(0.0,0.0,-1.2),0.5, material_center)));
    world.add(Arc::new(Sphere::new(Vector3::new(-1.0,0.0,-1.0),0.5, material_left)));
    world.add(Arc::new(Sphere::new(Vector3::new(1.0,0.0,-1.0),0.5, material_right)));
    let mut cam = Camera::new();
    cam.aspect_ratio = 16.0 / 9.0;
    cam.image_width  = 400;
    cam.samples_per_pixel = 100;
    cam.max_depth = 50;
    cam.render(&world);
}