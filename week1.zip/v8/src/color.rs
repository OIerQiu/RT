use nalgebra::Vector3;
use crate::interval::Interval;

pub fn write_color(pixel_color:&Vector3<f64>) {
    let r = pixel_color.x;
    let g = pixel_color.y;
    let b = pixel_color.z;
    let intensity = Interval::new(0.000,0.999);
    let rbyte = (256.0 * intensity.clamp(r)) as i64;
    let gbyte = (256.0 * intensity.clamp(g)) as i64;
    let bbyte = (256.0 * intensity.clamp(b)) as i64;
    println!("{} {} {}",rbyte,gbyte,bbyte);
}