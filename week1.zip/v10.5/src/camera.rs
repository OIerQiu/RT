use nalgebra::Vector3;
use indicatif::{ProgressBar, ProgressStyle};

use crate::ray::Ray;
use crate::hittable_list::HittableList;
use crate::hittable::{HitRecord,Hittable};
use crate::interval::Interval;
use crate::color::write_color;
use crate::rtweekend::random_double;
use crate::vec3::{random_on_hemisphere,random_unit_vector};
use crate::material::Material;

pub struct Camera {
    pub aspect_ratio:f64,
    pub image_width:i64,
    pub samples_per_pixel:i64,
    pub max_depth:i64,
    pub image_height:i64,
    pixel_samples_scale:f64,
    pub center:Vector3<f64>,
    pub pixel00_loc:Vector3<f64>,
    pub pixel_delta_u:Vector3<f64>,
    pub pixel_delta_v:Vector3<f64>,
}

impl Camera {
    pub fn new () -> Self {
        Camera {
            aspect_ratio:1.0,
            image_width:100,
            samples_per_pixel:10,
            max_depth:10,
            image_height:100,
            pixel_samples_scale:0.0,
            center:Vector3::new(0.0,0.0,0.0),
            pixel00_loc:Vector3::new(0.0,0.0,0.0),
            pixel_delta_u:Vector3::new(0.0,0.0,0.0),
            pixel_delta_v:Vector3::new(0.0,0.0,0.0),
        }
    }
    pub fn ray_color ( r:&Ray, depth:i64, world:&HittableList) -> Vector3<f64> {
        if depth <= 0 {
            return Vector3::new(0.0,0.0,0.0);
        }
        let mut rec = HitRecord::new();
        if world.hit(&r,&Interval::new(0.001, f64::INFINITY),&mut rec) {
            let mut scattered = Ray::new(Vector3::zeros(),Vector3::zeros());
            let mut attenuation:Vector3<f64> = Vector3::zeros();
            if rec.mat.scatter(&r, &rec, &mut attenuation, &mut scattered) {
                return attenuation.component_mul(&Self::ray_color(&scattered, depth-1, &world));
            }
            return Vector3::zeros();
        }
        let unit_direction = r.direction().normalize();
        let a = 0.5*(unit_direction.y + 1.0);
        (1.0 - a)*Vector3::new(1.0,1.0,1.0)+a*Vector3::new(0.5,0.7,1.0)
    }

    pub fn render(&mut self, world:&HittableList) {
        self.initialize();
        println!("P3");
        println!("{} {}",self.image_width, self.image_height);
        println!("255");

        let mut pb = ProgressBar::new(self.image_height as u64);
        pb.set_style(ProgressStyle::default_bar()
            .template("[{elapsed_precise}] {bar:40.cyan/blue} {pos:>7}/{len:7} {percent:>7}%"));
        for j in 0..self.image_height {
            pb.set_position(j as u64);
            for i in 0..self.image_width {
                let mut pixel_color = Vector3::new(0.0,0.0,0.0);
                for sample in 0..self.samples_per_pixel{
                    let r = self.get_ray(i,j);
                    pixel_color += Self::ray_color(&r,self.max_depth,&world);
                }
                write_color(&(self.pixel_samples_scale * pixel_color));
            }
        }
        pb.finish_and_clear();
    }

    pub fn initialize(&mut self) {
        self.image_height = (self.image_width as f64 / self.aspect_ratio) as i64;
        if self.image_height < 1 {
            self.image_height = 1;
        }
        self.pixel_samples_scale = 1.0 / self.samples_per_pixel as f64;
        self.center = Vector3::new(0.0,0.0,0.0);
        let focal_length = 1.0;
        let viewport_height = 2.0;
        let viewport_width = viewport_height * (self.image_width as f64 / self.image_height as f64);
        let viewport_u = Vector3::new(viewport_width,0.0,0.0);
        let viewport_v = Vector3::new(0.0,-viewport_height,0.0);
        self.pixel_delta_u = viewport_u / self.image_width as f64;
        self.pixel_delta_v = viewport_v / self.image_height as f64;
        let viewport_upper_left = self.center - Vector3::new(0.0,0.0,focal_length)-viewport_u/2.0-viewport_v/2.0;
        self.pixel00_loc = viewport_upper_left + 0.5 * (self.pixel_delta_u + self.pixel_delta_v);
    }

    pub fn get_ray(&self,i:i64, j:i64) -> Ray {
        let offset = Self::sample_square();
        let pixel_sample = self.pixel00_loc + (i as f64+offset.x) * self.pixel_delta_u + (j as f64+offset.y) * self.pixel_delta_v;
        let ray_origin = self.center;
        let ray_direction = pixel_sample - ray_origin;
        Ray::new(ray_origin, ray_direction)
    }

    pub fn sample_square() -> Vector3<f64> {
        Vector3::new(random_double()-0.5,random_double()-0.5,0.0)
    }
}