use nalgebra::Vector3;

pub struct Interval {
    pub min:f64,
    pub max:f64,
}

impl Interval {
    pub fn new() -> Self {
        Interval {
            min:f64::INFINITY,
            max:f64::NEG_INFINITY,
        }
    }

    pub fn initial(mn:f64, mx:f64) -> Self {
        Interval {
            min:mn,
            max:mx,
        }
    }

    pub fn size(&self) -> f64 {
        self.max - self.min
    }

    pub fn contains(&self, x:f64) -> bool {
        self.min <= x && x <= self.max
    }

    pub fn surrounds(&self, x:f64) -> bool {
        self.min < x && x < self.max
    }

    pub fn empty() -> Self {
        Self::initial(f64::INFINITY, f64::NEG_INFINITY)
    }

    pub fn universe() -> Self {
        Self::initial(f64::NEG_INFINITY, f64::INFINITY)
    }
}
