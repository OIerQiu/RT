use nalgebra::Vector3;
use rand::random;

use crate::rtweekend::{random_double, random_int};

const POINT_COUNT: i64 = 256;

pub struct Perlin {
    randfloat:Vec<f64>,
    perm_x:Vec<i64>,
    perm_y:Vec<i64>,
    perm_z:Vec<i64>,
}

impl Perlin {
    pub fn new() -> Self {
        let mut randfloat:Vec<f64> = Vec::new();
        for i in 0..POINT_COUNT {
            randfloat.push(random_double());
        }
        Perlin {
            randfloat:randfloat,
            perm_x:Self::perlin_generate_perm(),
            perm_y:Self::perlin_generate_perm(),
            perm_z:Self::perlin_generate_perm(),
        }
    }

    pub fn noise (&self, p:&Vector3<f64>) -> f64 {
        let i = (4.0 * p.x) as i64 & 255;
        let j = (4.0 * p.y) as i64 & 255;
        let k = (4.0 * p.z) as i64 & 255;
        self.randfloat[(self.perm_x[i as usize] ^ self.perm_y[j as usize] ^ self.perm_z[k as usize]) as usize]
    }

    pub fn perlin_generate_perm() -> Vec<i64> {
        let mut p:Vec<i64> = Vec::new();
        for i in 0..POINT_COUNT {
            p.push(i);
        }
        Self::permute(&mut p, POINT_COUNT);
        p
    }

    pub fn permute(p:&mut Vec<i64>, n:i64) {
        for i in 0..n-1 {
            let i = n-1-i;
            let target = random_int(0, i);
            let tmp = p[i as usize];
            p[i as usize] = p[target as usize];
            p[target as usize] = tmp;
        }
    }
}