use nalgebra::Vector3;
use std::sync::Arc;

use crate::ray::Ray;
use crate::hittable::{Hittable, HitRecord};
use crate::interval::Interval;
use crate::material::Material;

pub struct Sphere {
    pub center1:Vector3<f64>,
    pub radius:f64,
    pub mat:Arc<dyn Material>,
    pub is_moving:bool,
    pub center_vec:Vector3<f64>,
}

impl Sphere {
    pub fn new(cent:Vector3<f64>, rad:f64, mate:Arc<dyn Material>) -> Self {
        Sphere {
            center1:cent.clone(),
            radius:rad,
            mat:mate.clone(),
            is_moving:false,
            center_vec:Vector3::zeros(),
        }
    }
    pub fn initial(center_1:Vector3<f64>, center2:Vector3<f64>, rad:f64, mate:Arc<dyn Material>) -> Self {
        Sphere {
            center1:center_1.clone(),
            radius:rad.max(0.0),
            mat:mate.clone(),
            is_moving:true,
            center_vec:center2 - center_1,
        }
    }
    pub fn sphere_center(&self, time:f64) -> Vector3<f64> {
        self.center1 + time * self.center_vec
    }
}

impl Hittable for Sphere {
    fn hit(&self, r:&Ray, ray_t:&Interval, rec:&mut HitRecord) -> bool {
        let mut center = self.center1;
        if self.is_moving {
            center = Self::sphere_center(&self, r.time());
        }
        let oc = center - r.origin();
        let a = r.direction().dot(&r.direction());
        let h = r.direction().dot(&oc);
        let c = oc.dot(&oc)-self.radius*self.radius;
        let discriminant = h*h - a*c;
        if discriminant < 0.0 {
            return false;
        }
        let sqrtd: f64 = discriminant.sqrt();
        let mut root = (h-sqrtd)/a;
        if !ray_t.surrounds(root) {
            root = (h+sqrtd)/a;
            if !ray_t.surrounds(root) {
                return false;
            }
        }
        rec.t = root;
        rec.p = r.at(rec.t);
        let outward_normal = (rec.p - center)/self.radius;
        rec.set_face_normal(&r, &outward_normal);
        rec.mat = self.mat.clone();
        true
    }
}