use nalgebra::Vector3;

use crate::{onb::Onb, vec3::{random_cosine_direction, random_unit_vector}};

pub trait Pdf: Send + Sync {
    fn value(&self, direction:&Vector3<f64>) -> f64;
    fn generate(&self) -> Vector3<f64>;
}

pub struct SpherePdf {}

impl SpherePdf {
    pub fn new() -> Self {
        SpherePdf {}
    }
}

impl Pdf for SpherePdf {
    fn value(&self, direction:&Vector3<f64>) -> f64 {
        1.0 / (4.0 * std::f64::consts::PI)
    }

    fn generate(&self) -> Vector3<f64> {
        random_unit_vector()
    }
}

pub struct CosinePdf {
    uvw:Onb,
}

impl CosinePdf {
    pub fn new(w:&Vector3<f64>) -> Self {
        let mut uvw = Onb::new();
        uvw.build_from_w(&w);
        CosinePdf {
            uvw:uvw,
        }
    }
}

impl Pdf for CosinePdf {
    fn value(&self, direction:&Vector3<f64>) -> f64 {
        let cosine_theta = direction.normalize().dot(&self.uvw.w());
        (cosine_theta/std::f64::consts::PI).max(0.0)
    }

    fn generate(&self) -> Vector3<f64> {
        self.uvw.local_vec(&random_cosine_direction())
    }
}